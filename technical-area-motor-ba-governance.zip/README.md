# Technical Area Motor BA - Governance

Portal simples para consulta e criação de Bugs Power BI no PDS. É uma aplicação independente, para ficar noutro repositório GitHub e ter o seu próprio deploy Cloudflare Pages, mas **não tem base de dados própria**.

Usa o mesmo Supabase do Team Flow Suite e escreve diretamente em `public.powerbi_bugs`. Assim, um bug criado no portal aparece na aplicação principal e uma alteração feita na aplicação principal aparece neste Kanban na atualização seguinte (e em tempo real quando a tabela estiver publicada no Supabase Realtime).

## O que inclui

- autenticação Supabase com as contas existentes;
- Kanban dos Bugs Power BI do PDS, usando os estados ativos do workflow `task`;
- detalhe de cada bug;
- criação de bugs, com associação obrigatória ao Report Power BI;
- arrastar um cartão para alterar estado, sujeito às permissões RLS existentes;
- sincronização por Realtime e atualização ao voltar para a página;
- configuração pronta para Cloudflare Pages.

## Não duplica dados

| Conceito | Fonte de verdade |
|---|---|
| Utilizadores e sessão | Supabase Auth existente |
| Bugs | `public.powerbi_bugs` |
| Estados do Kanban | `public.workflows` + `public.workflow_statuses` (scope `task`) |
| Reports disponíveis | `public.powerbi_reports` |
| Prioridades | `public.priorities` |

Não criar uma nova tabela de bugs para este portal. As duas aplicações comunicam precisamente por partilharem estas entidades.

## Configuração local

```bash
npm install
cp .env.example .env
npm run dev
```

No `.env`, configurar os valores do mesmo projeto Supabase usado pelo Team Flow Suite:

```bash
VITE_SUPABASE_URL=https://<project-ref>.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_<chave-publica>
```

Estas chaves são públicas e próprias para browser. **Nunca** colocar `SUPABASE_SERVICE_ROLE_KEY` nesta aplicação, no GitHub ou no Cloudflare Pages.

## Permissões

A app respeita as políticas RLS atuais do projeto partilhado:

- qualquer utilizador autenticado com acesso de leitura vê os bugs permitidos;
- administradores e utilizadores com `development.contribute` já podem criar e mudar o estado de bugs;
- se utilizadores sem essa permissão também tiverem de submeter bugs, aplicar uma vez o ficheiro opcional:

```text
supabase/optional-migrations/202609090001_allow_portal_bug_submission.sql
```

Essa migration opcional só permite criar bugs do próprio utilizador; não abre a alteração de estado a todos os utilizadores.

## Publicar no GitHub e Cloudflare

1. Criar um repositório novo no GitHub, por exemplo `technical-area-motor-ba-governance`.
2. Extrair o conteúdo deste ZIP na raiz desse repositório e fazer commit.
3. No Cloudflare: **Workers & Pages → Create → Pages → Connect to Git**.
4. Escolher o repositório e configurar:

| Campo Cloudflare Pages | Valor |
|---|---|
| Framework preset | Vite |
| Build command | `npm run build` |
| Build output directory | `dist` |
| `VITE_SUPABASE_URL` | URL do Supabase existente |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | chave publishable existente |

5. Publicar e abrir a URL do novo portal.

Também é possível publicar pela linha de comandos após `wrangler login`:

```bash
npm run deploy
```

## Antes de publicar

```bash
npm run build
```

Testar:

- login com uma conta existente;
- criação de um bug associado a um Report;
- visibilidade imediata do bug em **Reports Power BI** / PDS da aplicação principal;
- alteração de estado por um utilizador com permissão;
- tentativa de alteração por um utilizador só de submissão, se usar a policy opcional.
