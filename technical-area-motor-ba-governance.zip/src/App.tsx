import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { AlertCircle, Bug, ChevronDown, CirclePlus, ExternalLink, LogOut, RefreshCw, X } from "lucide-react";
import { supabase } from "./lib/supabase";
import type { Bug as BugRow, Priority, Report, Status, Workflow } from "./lib/types";

const BUG_SELECT =
  "id, code, powerbi_report_id, title, description, status_id, priority_id, assignee_id, start_date, due_date, is_blocked, created_at, created_by";

type BoardData = {
  bugs: BugRow[];
  reports: Report[];
  statuses: Status[];
  priorities: Priority[];
};

type Notice = { kind: "success" | "error"; text: string } | null;

function readableDate(date: string | null) {
  if (!date) return "Sem data alvo";

  return new Intl.DateTimeFormat("pt-PT", { day: "2-digit", month: "short", year: "numeric" }).format(
    new Date(`${date.slice(0, 10)}T00:00:00`),
  );
}

function isLate(date: string | null) {
  if (!date) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(`${date.slice(0, 10)}T00:00:00`) < today;
}

function errorText(error: unknown) {
  return error instanceof Error ? error.message : "Ocorreu um erro inesperado.";
}

export function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [checkingSession, setCheckingSession] = useState(true);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setCheckingSession(false);
    });

    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => data.subscription.unsubscribe();
  }, []);

  if (checkingSession) return <main className="app-loading">A validar sessão…</main>;
  if (!session) return <Login />;

  return <BugsBoard session={session} />;
}

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError(null);

    const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (signInError) setError(signInError.message);
    setBusy(false);
  };

  return (
    <main className="auth-shell">
      <section className="auth-card" aria-labelledby="login-title">
        <div className="brand-mark"><Bug aria-hidden /></div>
        <p className="eyebrow">TECHNICAL AREA MOTOR BA</p>
        <h1 id="login-title">Governance</h1>
        <p className="muted">Entre com as mesmas credenciais usadas na aplicação principal.</p>

        <form onSubmit={submit} className="form-stack">
          <label>
            Email
            <input type="email" required autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} />
          </label>
          <label>
            Palavra-passe
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </label>
          {error ? <p className="inline-error"><AlertCircle aria-hidden />{error}</p> : null}
          <button className="primary-button" disabled={busy}>{busy ? "A entrar…" : "Entrar"}</button>
        </form>
      </section>
    </main>
  );
}

function BugsBoard({ session }: { session: Session }) {
  const [data, setData] = useState<BoardData>({ bugs: [], reports: [], statuses: [], priorities: [] });
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<Notice>(null);
  const [showNewBug, setShowNewBug] = useState(false);
  const [selectedBug, setSelectedBug] = useState<BugRow | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);

  const loadBoard = useCallback(async () => {
    setLoading(true);
    const [bugsResult, reportsResult, workflowsResult, allStatusesResult, prioritiesResult] = await Promise.all([
      supabase.from("powerbi_bugs").select(BUG_SELECT).order("created_at", { ascending: false }),
      supabase.from("powerbi_reports").select("id, code, name").order("name"),
      supabase.from("workflows").select("id, scope").eq("scope", "task").eq("is_active", true),
      supabase.from("workflow_statuses").select("id, workflow_id, name, category, color, sort_order").eq("is_active", true).order("sort_order"),
      supabase.from("priorities").select("id, name, color").eq("is_active", true).order("sort_order"),
    ]);

    const firstError = [bugsResult, reportsResult, workflowsResult, allStatusesResult, prioritiesResult].find((result) => result.error)?.error;
    if (firstError) {
      setNotice({ kind: "error", text: firstError.message });
      setLoading(false);
      return;
    }

    const taskWorkflowIds = new Set(((workflowsResult.data ?? []) as Workflow[]).map((workflow) => workflow.id));
    setData({
      bugs: (bugsResult.data ?? []) as BugRow[],
      reports: (reportsResult.data ?? []) as Report[],
      statuses: ((allStatusesResult.data ?? []) as Status[]).filter((status) => taskWorkflowIds.has(status.workflow_id)),
      priorities: (prioritiesResult.data ?? []) as Priority[],
    });
    setLoading(false);
  }, []);

  useEffect(() => {
    void loadBoard();
    const channel = supabase
      .channel("technical-area-motor-ba-governance-sync")
      .on("postgres_changes", { event: "*", schema: "public", table: "powerbi_bugs" }, () => void loadBoard())
      .subscribe();
    const onFocus = () => void loadBoard();
    window.addEventListener("focus", onFocus);
    return () => {
      window.removeEventListener("focus", onFocus);
      void supabase.removeChannel(channel);
    };
  }, [loadBoard]);

  const reportById = useMemo(() => new Map(data.reports.map((report) => [report.id, report])), [data.reports]);
  const priorityById = useMemo(() => new Map(data.priorities.map((priority) => [priority.id, priority])), [data.priorities]);
  const columns = useMemo(() => [{ id: "unassigned", name: "Sem estado", color: "#94a3b8", category: "open" }, ...data.statuses], [data.statuses]);

  const changeStatus = async (bugId: string, statusId: string) => {
    if (statusId === "unassigned") return;
    const { error } = await supabase.from("powerbi_bugs").update({ status_id: statusId }).eq("id", bugId);
    if (error) {
      setNotice({ kind: "error", text: `Não foi possível alterar o estado: ${error.message}` });
      return;
    }
    setNotice({ kind: "success", text: "Estado atualizado. A aplicação principal verá a alteração de imediato." });
    await loadBoard();
  };

  const onDrop = (statusId: string) => {
    if (draggingId) void changeStatus(draggingId, statusId);
    setDraggingId(null);
  };

  return (
    <main className="board-shell">
      <header className="topbar">
        <div className="title-group">
          <div className="brand-mark small"><Bug aria-hidden /></div>
          <div>
            <p className="eyebrow">TECHNICAL AREA MOTOR BA</p>
            <h1>Governance · PDS Bugs</h1>
          </div>
        </div>
        <div className="header-actions">
          <span className="user-email">{session.user.email}</span>
          <button className="icon-button" title="Atualizar" onClick={() => void loadBoard()} disabled={loading}><RefreshCw aria-hidden /></button>
          <button className="secondary-button" onClick={() => void supabase.auth.signOut()}><LogOut aria-hidden /> Sair</button>
        </div>
      </header>

      <section className="intro-row">
        <div>
          <h2>Kanban de bugs</h2>
          <p>Consulta e regista bugs dos Reports Power BI. Esta página usa a mesma base de dados e os mesmos estados da aplicação principal.</p>
        </div>
        <button className="primary-button" onClick={() => setShowNewBug(true)}><CirclePlus aria-hidden /> Novo bug</button>
      </section>

      {notice ? (
        <div className={`notice ${notice.kind}`} role="status">
          <span>{notice.text}</span><button title="Fechar mensagem" onClick={() => setNotice(null)}><X aria-hidden /></button>
        </div>
      ) : null}

      {loading ? <p className="loading-panel">A carregar bugs e workflow…</p> : (
        <section className="kanban" aria-label="Kanban de Bugs PDS">
          {columns.map((column) => {
            const bugs = data.bugs.filter((bug) => (bug.status_id ?? "unassigned") === column.id);
            return (
              <article
                className="kanban-column"
                key={column.id}
                onDragOver={(event) => event.preventDefault()}
                onDrop={() => onDrop(column.id)}
              >
                <header className="column-title" style={{ borderTopColor: column.color }}>
                  <span>{column.name}</span><b>{bugs.length}</b>
                </header>
                <div className="column-content">
                  {bugs.map((bug) => (
                    <BugCard
                      key={bug.id}
                      bug={bug}
                      report={reportById.get(bug.powerbi_report_id)}
                      priority={bug.priority_id ? priorityById.get(bug.priority_id) : undefined}
                      onOpen={() => setSelectedBug(bug)}
                      onDragStart={() => setDraggingId(bug.id)}
                    />
                  ))}
                  {bugs.length === 0 ? <p className="empty-column">Sem bugs</p> : null}
                </div>
              </article>
            );
          })}
        </section>
      )}

      {showNewBug ? (
        <NewBugModal
          session={session}
          reports={data.reports}
          priorities={data.priorities}
          defaultStatus={data.statuses.find((status) => status.category === "open") ?? data.statuses[0]}
          onClose={() => setShowNewBug(false)}
          onSaved={async (message) => { setShowNewBug(false); setNotice({ kind: "success", text: message }); await loadBoard(); }}
          onError={(message) => setNotice({ kind: "error", text: message })}
        />
      ) : null}

      {selectedBug ? (
        <BugDetails
          bug={selectedBug}
          report={reportById.get(selectedBug.powerbi_report_id)}
          status={data.statuses.find((status) => status.id === selectedBug.status_id)}
          priority={selectedBug.priority_id ? priorityById.get(selectedBug.priority_id) : undefined}
          onClose={() => setSelectedBug(null)}
        />
      ) : null}
    </main>
  );
}

function BugCard({ bug, report, priority, onOpen, onDragStart }: { bug: BugRow; report?: Report; priority?: Priority; onOpen: () => void; onDragStart: () => void }) {
  return (
    <button className="bug-card" draggable onDragStart={onDragStart} onClick={onOpen}>
      <span className="bug-code">{bug.code}</span>
      <strong>{bug.title}</strong>
      <span className="report-name">{report ? `${report.code} · ${report.name}` : "Report não disponível"}</span>
      <footer>
        {bug.is_blocked ? <span className="pill blocked">Bloqueado</span> : null}
        {priority ? <span className="pill" style={{ borderColor: priority.color ?? "#cbd5e1" }}>{priority.name}</span> : null}
        <span className={isLate(bug.due_date) ? "due-date late" : "due-date"}>{readableDate(bug.due_date)}</span>
      </footer>
    </button>
  );
}

function NewBugModal({ session, reports, priorities, defaultStatus, onClose, onSaved, onError }: { session: Session; reports: Report[]; priorities: Priority[]; defaultStatus?: Status; onClose: () => void; onSaved: (message: string) => void; onError: (message: string) => void }) {
  const [reportId, setReportId] = useState(reports[0]?.id ?? "");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priorityId, setPriorityId] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (title.trim().length < 3) { onError("Indique um título com pelo menos 3 caracteres."); return; }
    if (!reportId) { onError("Selecione o Report Power BI afetado."); return; }
    if (!defaultStatus) { onError("Não existe um estado ativo no workflow de Tasks. Configure-o na aplicação principal."); return; }

    setBusy(true);
    const { error } = await supabase.from("powerbi_bugs").insert({
      code: "",
      powerbi_report_id: reportId,
      title: title.trim(),
      description: description.trim() || null,
      status_id: defaultStatus.id,
      priority_id: priorityId || null,
      due_date: dueDate || null,
      created_by: session.user.id,
    });
    setBusy(false);
    if (error) { onError(`Não foi possível criar o bug: ${error.message}`); return; }
    onSaved("Bug criado. Já está disponível no PDS e na aplicação principal.");
  };

  return (
    <Modal title="Novo bug" onClose={onClose}>
      <form className="form-stack" onSubmit={submit}>
        <label>Report Power BI<select value={reportId} required onChange={(event) => setReportId(event.target.value)}><option value="">Selecionar report…</option>{reports.map((report) => <option key={report.id} value={report.id}>{report.code} · {report.name}</option>)}</select></label>
        {reports.length === 0 ? <p className="inline-error"><AlertCircle aria-hidden />Não existem Reports Power BI disponíveis para o seu utilizador.</p> : null}
        <label>Título<input autoFocus required value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Ex.: Valor incorreto no indicador de sinistralidade" /></label>
        <label>Descrição<textarea rows={4} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Descreva o comportamento observado e, se possível, inclua exemplos." /></label>
        <div className="two-fields">
          <label>Prioridade<select value={priorityId} onChange={(event) => setPriorityId(event.target.value)}><option value="">Sem prioridade</option>{priorities.map((priority) => <option key={priority.id} value={priority.id}>{priority.name}</option>)}</select></label>
          <label>Data alvo<input type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} /></label>
        </div>
        <p className="hint">O novo bug entra em <b>{defaultStatus?.name ?? "estado inicial"}</b>. O código é atribuído automaticamente pelo Supabase.</p>
        <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancelar</button><button className="primary-button" disabled={busy || reports.length === 0}>{busy ? "A guardar…" : "Criar bug"}</button></div>
      </form>
    </Modal>
  );
}

function BugDetails({ bug, report, status, priority, onClose }: { bug: BugRow; report?: Report; status?: Status; priority?: Priority; onClose: () => void }) {
  return (
    <Modal title={bug.code} onClose={onClose}>
      <div className="details">
        <h3>{bug.title}</h3>
        <dl>
          <div><dt>Report</dt><dd>{report ? `${report.code} · ${report.name}` : "Não disponível"}</dd></div>
          <div><dt>Estado</dt><dd><span className="status-dot" style={{ backgroundColor: status?.color ?? "#94a3b8" }} />{status?.name ?? "Sem estado"}</dd></div>
          <div><dt>Prioridade</dt><dd>{priority?.name ?? "Sem prioridade"}</dd></div>
          <div><dt>Data alvo</dt><dd>{readableDate(bug.due_date)}</dd></div>
          <div><dt>Bloqueado</dt><dd>{bug.is_blocked ? "Sim" : "Não"}</dd></div>
        </dl>
        <div className="description"><b>Descrição</b><p>{bug.description || "Sem descrição."}</p></div>
      </div>
      <div className="modal-actions"><button className="secondary-button" onClick={onClose}>Fechar</button></div>
    </Modal>
  );
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={onClose}><section className="modal" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => event.stopPropagation()}><header><h2>{title}</h2><button className="icon-button" title="Fechar" onClick={onClose}><X aria-hidden /></button></header>{children}</section></div>;
}
