export type Bug = {
  id: string;
  code: string;
  powerbi_report_id: string;
  title: string;
  description: string | null;
  status_id: string | null;
  priority_id: string | null;
  assignee_id: string | null;
  start_date: string | null;
  due_date: string | null;
  is_blocked: boolean;
  created_at: string;
  created_by: string | null;
};

export type Report = {
  id: string;
  code: string;
  name: string;
};

export type Status = {
  id: string;
  workflow_id: string;
  name: string;
  category: "open" | "in_progress" | "blocked" | "completed" | "cancelled" | string;
  color: string;
  sort_order: number;
};

export type Workflow = {
  id: string;
  scope: string;
};

export type Priority = {
  id: string;
  name: string;
  color: string | null;
};
