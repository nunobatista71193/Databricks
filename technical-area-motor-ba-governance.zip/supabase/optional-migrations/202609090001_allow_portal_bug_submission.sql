-- OPCIONAL — aplicar apenas se utilizadores autenticados sem a permissão
-- "development.contribute" também tiverem de submeter bugs pelo portal.
--
-- Esta policy permite SOMENTE criar bugs. A alteração de estado continua a
-- respeitar a policy existente de update, ou seja, fica limitada a quem tem
-- permissão de contribuir em Development ou é administrador.
--
-- Aplicar uma única vez no SQL Editor do MESMO projeto Supabase usado pelo
-- Team Flow Suite. Não cria tabelas, nem duplica dados.

CREATE POLICY "powerbi_bugs_portal_submit_authenticated"
ON public.powerbi_bugs
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() IS NOT NULL
  AND created_by = auth.uid()
);
